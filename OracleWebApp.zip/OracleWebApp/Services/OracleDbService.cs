using Oracle.ManagedDataAccess.Client;
using System.Data;
using Microsoft.Extensions.Configuration;
using OracleWebApp.Models;

namespace OracleWebApp.Services

{
    public class OracleDbService
    {
        private readonly IConfiguration _config;
        private readonly string _connectionString;

        public OracleDbService(IConfiguration config)
        {
            _config = config;
            _connectionString = _config.GetConnectionString("OracleDb");
        }

        private OracleConnection GetConnection()
        {
            return new OracleConnection(_connectionString);
        }

         public async Task<int> InsertAuditAsync(string element, string auditor, DateTime date, string status)
        {
        using var conn = GetConnection();
        await conn.OpenAsync();

        using var cmd = new OracleCommand("insert_audit", conn)
        {
            CommandType = CommandType.StoredProcedure
        };

        cmd.Parameters.Add("p_element_name", OracleDbType.Varchar2).Value = element;
        cmd.Parameters.Add("p_auditor", OracleDbType.Varchar2).Value = auditor;
        cmd.Parameters.Add("p_date", OracleDbType.Date).Value = date;
        cmd.Parameters.Add("p_status", OracleDbType.Varchar2).Value = status;

        return await cmd.ExecuteNonQueryAsync();
        }

        public User Authenticate(string username, string password)
        {
            using var con = GetConnection();
            con.Open();
            var cmd = new OracleCommand("SELECT * FROM users WHERE username = :username AND password = :password", con);
            cmd.Parameters.Add(new OracleParameter("username", username));
            cmd.Parameters.Add(new OracleParameter("password", password));
            var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new User
                {
                    Id = Convert.ToInt32(reader["id"]),
                    Username = reader["username"].ToString(),
                    Role = reader["role"].ToString()
                };
            }
            return null;
        }

        public List<Element> GetElements()
        {
            var elements = new List<Element>();
            using var con = GetConnection();
            con.Open();
            var cmd = new OracleCommand("SELECT * FROM elements", con);
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                elements.Add(new Element
                {
                    Id = Convert.ToInt32(reader["id"]),
                    Name = reader["name"].ToString(),
                    Type = reader["type"].ToString(),
                    Location = reader["location"].ToString(),
                    Status = reader["status"].ToString()
                });
            }
            return elements;
        }

        public void AddElement(Element element)
        {
            using var con = GetConnection();
            con.Open();
            var cmd = new OracleCommand("INSERT INTO elements (name, type, location, status) VALUES (:name, :type, :location, :status)", con);
            cmd.Parameters.Add(new OracleParameter("name", element.Name));
            cmd.Parameters.Add(new OracleParameter("type", element.Type));
            cmd.Parameters.Add(new OracleParameter("location", element.Location));
            cmd.Parameters.Add(new OracleParameter("status", element.Status));
            cmd.ExecuteNonQuery();
        }

        // Add this inside OracleDbService class

// Schedule Audit
public void ScheduleAudit(Audit audit)
{
    using var con = GetConnection();
    con.Open();
    var cmd = new OracleCommand("INSERT INTO audits (element_name, auditor, scheduled_date, status) VALUES (:element, :auditor, :date, :status)", con);
    cmd.Parameters.Add(new OracleParameter("element", audit.ElementName));
    cmd.Parameters.Add(new OracleParameter("auditor", audit.Auditor));
    cmd.Parameters.Add(new OracleParameter("date", audit.ScheduledDate));
    cmd.Parameters.Add(new OracleParameter("status", audit.Status));
    cmd.ExecuteNonQuery();
}

// Get All Audits
public List<Audit> GetAudits()
{
    var audits = new List<Audit>();
    using var con = GetConnection();
    con.Open();
    var cmd = new OracleCommand("SELECT * FROM audits ORDER BY scheduled_date DESC", con);
    var reader = cmd.ExecuteReader();
    while (reader.Read())
    {
        audits.Add(new Audit
        {
            Id = Convert.ToInt32(reader["id"]),
            ElementName = reader["element_name"].ToString(),
            Auditor = reader["auditor"].ToString(),
            ScheduledDate = Convert.ToDateTime(reader["scheduled_date"]),
            Status = reader["status"].ToString()
        });
    }
    return audits;
}

    }
}
