using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using OracleWebApp.Models;
using OracleWebApp.Services;


namespace OracleWebApp.Controllers;



public class HomeController : Controller
{
    private readonly OracleDbService _db;

    public HomeController(OracleDbService db)
    {
        _db = db;
    }

    public IActionResult Index()
    {
        var elements = _db.GetElements();
        var audits = _db.GetAudits();

        ViewBag.TotalElements = elements.Count;
        ViewBag.TotalAudits = audits.Count;
        ViewBag.UpcomingAudits = audits.Where(a => a.ScheduledDate >= DateTime.Today).Count();

        return View();
    }
}

