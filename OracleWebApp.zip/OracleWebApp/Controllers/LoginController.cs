using Microsoft.AspNetCore.Mvc;
using OracleWebApp.Models;
using OracleWebApp.Services;

namespace OracleWebApp.Controllers
{
    public class LoginController : Controller
    {
        private readonly OracleDbService _db;

        public LoginController(OracleDbService db)
        {
            _db = db;
        }

        // GET: /Login
        public IActionResult Index()
        {
            return View();
        }

        // POST: /Login
        [HttpPost]
        public IActionResult Index(User user)
        {
            var found = _db.Authenticate(user.Username, user.Password);
            if (found != null)
            {
                TempData["Username"] = found.Username;
                return RedirectToAction("Index", "Element");
            }

            ViewBag.Error = "Invalid username or password.";
            return View();
        }
    }
}
