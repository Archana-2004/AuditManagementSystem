using Microsoft.AspNetCore.Mvc;
using OracleWebApp.Models;
using OracleWebApp.Services;

namespace OracleWebApp.Controllers
{
    public class ElementController : Controller
    {
        private readonly OracleDbService _db;

        public ElementController(OracleDbService db)
        {
            _db = db;
        }

        // GET: /Element
        public IActionResult Index()
        {
            var elements = _db.GetElements();
            return View(elements);
        }

        // GET: /Element/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Element/Create
        [HttpPost]
        public IActionResult Create(Element element)
        {
            _db.AddElement(element);
            return RedirectToAction("Index");
        }
    }
}
