using Microsoft.AspNetCore.Mvc;
using OracleWebApp.Models;
using OracleWebApp.Services;

namespace OracleWebApp.Controllers
{
    public class AuditController : Controller
    {
        private readonly OracleDbService _oracle;

        public AuditController(OracleDbService oracle)
        {
            _oracle = oracle;
        }

        // Show list of all audits
        public IActionResult Index()
        {
            var audits = _oracle.GetAudits(); // ✅ Corrected _oracle
            return View(audits);
        }

        // Show schedule form
        [HttpGet]
        public IActionResult Schedule()
        {
            return View();
        }

        // Handle form submission
        [HttpPost]
        public IActionResult Schedule(Audit audit)
        {
            audit.Status = "Scheduled";
            _oracle.ScheduleAudit(audit); // ✅ Corrected _oracle
            ViewBag.Message = "Audit scheduled successfully!";
            return View();
        }

        // Optional: Create method if you want an API-style form
        [HttpPost]
        public async Task<IActionResult> Create(string element, string auditor, DateTime date, string status)
        {
            await _oracle.InsertAuditAsync(element, auditor, date, status);
            ViewBag.Message = "Audit inserted successfully!";
            return View();
        }
    }
}
