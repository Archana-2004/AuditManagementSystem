namespace OracleWebApp.Models
{
public class Audit
{
    public int Id { get; set; }
    public string ElementName { get; set; }
    public string Auditor { get; set; }
    public DateTime ScheduledDate { get; set; }
    public string Status { get; set; }  // Scheduled, Completed, etc.
}
}
